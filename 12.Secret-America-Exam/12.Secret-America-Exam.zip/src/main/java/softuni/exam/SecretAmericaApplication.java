package softuni.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecretAmericaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecretAmericaApplication.class, args);
    }

}
