package org.softuni.jsonprocessingexercise.service;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface ProductService {
    void seedProducts() throws IOException;
}
