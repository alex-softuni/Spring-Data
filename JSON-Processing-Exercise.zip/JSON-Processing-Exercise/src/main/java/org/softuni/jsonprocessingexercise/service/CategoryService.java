package org.softuni.jsonprocessingexercise.service;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface CategoryService {
    void seedCategories() throws IOException;
}
